<?php
namespace admin\change_orgs;

class add extends \Admin {

    var $change_org_data;
    var $api_base_url = "https://api.change.org/v1/";
    
    function default_method(){
        $this->getChangeOrgData();
        if (filter_input(INPUT_POST, "url") != ""){
            $change_org = $this->getPetition($_POST);
            if (!$this->add($change_org, $err)){
                $message = $this->getMessage(false, $err);
                $this->showRes($message);
            }
            else {
                $this->redirect("/admin/change_orgs");
            }
        }
        else{
            $this->layout_show("admin/add.html", $data);
        }
    }
    
    private function getPetition($petition){
        
        $lPetition = new \stdClass();
        $lPetition->name = $petition['name'];
        $lPetition->url = $petition['url'];
        $lPetition->api_key = $petition['api_key'];
        $lPetition->api_secret_token = $petition['api_secret_token'];
        $lPetition->public_id = $this->getPetitionId($lPetition);
        
        return $lPetition;
    }
    
    function getSignsRecent($petition, $recentCount){
        $endpoint = "petitions/" . $petition->public_id . "/signatures";
        $params = array(
            'api_key' => $petition->api_key,
            'page_size' => $recentCount,
            'sort' => 'time_desc'
        );
        $signs = $this->getRequest($endpoint, $params, $err);
        
        return $signs;
    }
    
    function getPetitionId($petition){
        $params = array(
            'api_key' => $petition->api_key,
            'petition_url' => $petition->url
        );
        $petitionID = $this->getRequest("petitions/get_id", $params);
        
        return $petitionID['petition_id'];
    }
    
    function getRequest($endpoint, $params, &$err = null){
        $query = http_build_query($params);
        $request = $this->api_base_url . $endpoint . "?" . $query;
        $response = file_get_contents($request);
        return json_decode($response, true);
    }
            
    function add($change_org, &$err) {
        $res = false;
        $data = $this->objToString($change_org);
        $insert = "INSERT INTO change_orgs SET {$data}";
        if (mysql_query($insert)){
            $res = true;
        }
        else {
            $err = mysql_error();
       }
       return $res;
    }
    
    function objToString($petition) {
        $res = "";
        foreach ($petition as $key => $value) {
            $value = mysql_real_escape_string($value);
            $res .= "{$key} = '{$value}', ";
        }
        $res = substr($res, 0, strlen($res) - 2);
        return $res;
    }
    
    private function showRes($message) {
        $this->layout = "/source/";
        $object = $this->layout_get("message.html", array('message'=>$message));
        $this->layout = "/applications/change_orgs/layouts/";
        $this->layout_show("admin/index.html", array('count'=>"1", 'object'=>$object));
    }
    
    private function getMessage($isAdd = false, $err = null){
        $message['href'] = "/admin/change_orgs";
        if ($isAdd){
            $message['text'] = "Учебник добавлен.";
        }
        else{
            $message['text'] = "При добавлении петиции произошла ошибка: ".$err;
        }
        return $message;
    }
    
    function getChangeOrgData(){
        $this->change_org_data = new \stdClass();
        $this->change_org_data->api_key = "d781837885cb1878c1a12460a5964c0d8065064cef95dcf3dfd0ab266d9a3366";
        $this->change_org_data->secret_token = "a58d7cacd7974cc466456811749a032e4bf2043e92340949f7a98c8983127ae9";
        $this->change_org_data->baseUrl = "https://api.change.org/v1/";
    }
    
}