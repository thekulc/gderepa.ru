<?php
namespace admin\change_orgs;

class change_orgs extends \Admin {

    function default_method()
    {
        $data = array();
        if (intval($this->id) > 0){
            $data['petition'] = $this->get($this->id);
        }
        else{
            $data['change_orgs'] = $this->getList();
        }
        
        return $this->layout_show('admin/index.html', $data);
    }
    
    function get($id) {
        return array_pop($this->select('id = '.$id));
    }
    
    function getList($where = "", $order = "", &$err = null){
        return $this->select($where, $order, $err);
    }
    
    private function select($where = "", $order = "", &$err = null){
        if ($where != "")
            $where = " WHERE " . mysql_real_escape_string ($where);
        if ($order != "")
            $order = " ORDER BY " . mysql_real_escape_string ($order);
        
        $select = "SELECT * FROM change_orgs" . $where . $order;
        if($list = mysql_query($select)){
            $change_orgs = array();
            while ($change_org = mysql_fetch_object($list)) {
                $change_orgs[$change_org->id] = $change_org;
            }
        }
        else{
            $err = mysql_error();
        }
        return $change_orgs;
    }
    
}
?>
