<?
namespace change_orgs;

class change_orgs extends \Controller {  
    
    function default_method()
    {
        return $this->layout_show('index.html');
    }
}
?>
