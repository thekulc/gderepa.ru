<?
namespace change_orgs;

class frame extends \Controller {  
    
    function default_method()
    {
        return $this->layout_show('index.html');
    }
}
?>
