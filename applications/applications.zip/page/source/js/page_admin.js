window.onload = function()
{
        var lEditor = CKEDITOR.replace( 'editor1' );
        CKFinder.setupCKEditor( lEditor, '/source/js/ckfinder/');
};
