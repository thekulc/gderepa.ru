$(document).ready(function(){
    /*$.localScroll({
  duration: 600,
  hash: false });
*/
    $('.menu-fixed a').click(menuItemClick);
});

function menuItemClick(){
    id = $(this).attr('href');
    $.scrollTo($(this).attr('href'), 600);
    return false;
}

function pr (txt){
    console.log(txt);
}