<?
namespace calendar;

class add_event extends \Controller {  
    function default_method() {
        $event = array();
        $lDate = filter_input(INPUT_GET, 'date');
        if (is_string($lDate)){
            $event['owner_id'] = $_SESSION['user']['id'];
            $event['title'] = "Репает " . $_SESSION['user']['FIO'];
            $event['type_id'] = 4;
            $event['date'] = date('Y-m-d 00:00:00', strtotime($lDate));
            echo $this->insert($event);
        }
    }
    
    function insert($event){
        $eventStr = $this->getStr($event);
        $sql = "INSERT INTO events SET " . $eventStr;
        if (!mysql_query($sql))
            return mysql_error ();
        else 
            return true;
    }
    
    function getStr($event){
        $res = "";
        foreach ($event as $key => $value) {
            $res .= $key . " = '" . $value . "', ";
        }
        
        return substr($res, 0, -2);
    }
}