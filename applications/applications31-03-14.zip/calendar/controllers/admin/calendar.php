<?
namespace admin\calendar;

class calendar extends \Admin {

    function default_method()
    {
        return $this->layout_show('admin/index.html');
    }
    
    function chooseAction(){
        
    }
    
}
?>
