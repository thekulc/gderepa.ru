<?
namespace calendar;

class calendar extends \Controller {  
    
    var $_date;
    const separator = '-';
    
    function default_method()
    {
        $data = array();
        
        if (is_string(filter_input(INPUT_POST, 'login'))){
            $login = filter_input(INPUT_POST, 'login');
            $pass = filter_input(INPUT_POST, 'password');
            
            $errs = $this->get_controller("users", "login", true)->login($login, $pass);
        }
        
        $date = filter_input(INPUT_GET, "date");
        if (!isset($date))
            $this->redirect('?date=' . date('Y-m'));

        $data = $this->chooseAction($date);
        $data['user'] = $_SESSION['user'];
        $data['errs'] = $errs;

        $data['page']['title'] = 'Расписание репетиционной студии';
        return $this->layout_show('index.html', $data);
    }
    
    function chooseAction($aDate) {
        $res = array();
        
        $lDate = $this->getDateObjByStr($aDate);
        if (isset($lDate['year']) AND isset($lDate['month'])){
            $res['calendar'] = $this->getMonth($aDate);
            $res['localdate']['choosed'] = date('d-m-Y');
            
            if ($lDate['month'] == 1){
                $res['localdate']['prevDate'] = (string)($lDate['year'] - 1) . '-12';
                $res['localdate']['nextDate'] = ($lDate['year']) . '-' . str_pad($lDate['month'] + 1, 2, '0', STR_PAD_LEFT);
            }
            elseif ($lDate['month'] == 12){
                $res['localdate']['prevDate'] = (string)($lDate['year']) . '-' . str_pad($lDate['month'] - 1, 2, '0', STR_PAD_LEFT);
                $res['localdate']['nextDate'] = (string)($lDate['year'] + 1) . '-02';
            }
            else {
                $res['localdate']['prevDate'] = (string)($lDate['year']) . '-' . str_pad($lDate['month'] - 1, 2, '0', STR_PAD_LEFT);
                $res['localdate']['nextDate'] = (string)($lDate['year']) . '-' . str_pad($lDate['month'] + 1, 2, '0', STR_PAD_LEFT);
            }
            
        }
        return $res;
    }
    
    function getMonth($date, $events = true) {
        $resArr = array();
        
        $day = new \DateTime($date);
        $i = 0;
        $week = 0;
        $weekDay = 0;
        $format = "d-m-Y";
        $days = array();
        $interval = \DateInterval::createFromDateString('1 day');
        if (($weekDay = $day->format('N')) > 1) {
            $day = $day->sub(\DateInterval::createFromDateString($weekDay - 1 . ' days'));
            for ($i = 0; $i < $weekDay; $i++) {
                $days[$week][$i] = $day->format($format);
                $day->add($interval);
            }
        }
        do {
            if ($i++ > 0 && ($weekDay = $day->format('N')) == 1) {
                $week++;
            }
            $days[$week][$weekDay - 1] = $day->format($format);
            $day = $day->add($interval);
        } while ($week < 4);

        if (($lastWeek = count($days) - 1) > 1 && ($lastWeekDaysCount = count($days[$lastWeek])) < 7) {
            for ($i = $lastWeekDaysCount; $i < 7; $i++) {
                $days[$lastWeek][$i] = $day->add($interval)->format($format);
            }
        }
        
        if ($events)
            $events = $this->getMonthEvents($date);
        else
            $events = false;
        
        for ($i = 0; $i < count($days); $i++) {
            foreach ($days[$i] as $day) {
                $resArr[$i][$day]['date'] = $day;
                if ($events)
                    $resArr[$i][$day]['events'] = $this->getEventByDate($events, $day);
            }
        }
        
        return $resArr;
    }
    
    function getEventByDate($events, $day) {
        $res = array();
        $format = 'd-m-Y';
        
        foreach ($events as $event) {
            if (date($format, strtotime($event->date)) === date($format, strtotime($day))){
                $res[] = $event;
            }
        }
        return $res;
    }
    
    function getMonthEvents($date){
        $dtStart = $date . '-01 00:00:00';
        $res = $this->select("date_format(`date`, '%Y%m') = date_format('{$dtStart}', '%Y%m')", "id, date, title, description, type_id, owner_id, (SELECT login FROM users WHERE id = owner_id LIMIT 1) as owner", "date DESC");
        return $res;
    }
    
    function getDateObjByStr($dateStr) {
        $lDate = explode(self::separator, $dateStr);
        $temp = $this->validYear($lDate[0]);
        if ($temp){
            $res['year'] = $temp;
            $temp = $this->validMonth($lDate[1]);
            if ($temp){
                $res['month'] = $temp;
                $temp = isset($lDate[2]) ? $this->validDay($lDate[2]) : null;
                if ($temp){
                    $res['day'] = $temp;
                }
                
            }
        }
        
        return $res;
    }
    
    private function validDay($day) {
        $res = null;
        if (strlen($day) > 0){
            $day = intval($day);
            if ($day > 0 && $day < 32){
                $res = $day;
            }
        }
        return $res;
    }
    
    private function validMonth($month) {
        $res = null;
        if (strlen($month) > 0){
            $month = intval($month);
            if ($month > 0 && $month < 13){
                $res = $month;
            }
        }
        return $res;
    }
    
    private function validYear($year) {
        $res = null;
        if (strlen($year) > 0){
            $year = intval($year);
            if ($year > 2000 && $year < 3000){
                $res = $year;
            }
        }
        return $res;
    }
    
    function select($where = null, $what = NULL, $order = null, &$err = NULL){
        if ($what)
            $sql = "SELECT ".$what." FROM events";
        else 
            $sql = "SELECT * FROM events";
        if ($where)
            $sql .= " WHERE ".$where;
        
        if($order)
            $sql .= " ORDER BY " . $order;
        
        $res = $this->getFetchedArray($sql, $err);
        
        return $res;
    }
    
    function getFormattedDate(){
        $year = $this->_date['year'];
        $month = $this->_date['month'];
        $day = $this->_date['day'];
        if (isset ($year) && isset($month) && isset($day) && $year != "" && $month != "" && $day != "")
            return str_pad($day, 2, "0", STR_PAD_LEFT) . self::separator . str_pad($month, 2, "0", STR_PAD_LEFT) . self::separator . $year;
    }
    
    private function getFetchedArray($sql, &$err){
        $res = array();
        if (strlen($sql) > 0){
            $result = mysql_query($sql);
            $res = $this->doFetch($result, $err);
        }
        else{
            $err = "Запрос к базе пуст!";
        }
        return $res;
    }
    
    private function doFetch($sqlRes, &$err) {
        $res = array();
        if (mysql_num_rows($sqlRes) > 0){
            while ($obj = mysql_fetch_object($sqlRes)) {
                $res[] = $obj;
            }
        }
        else {
            $err = mysql_error();
        }
        return $res;
    } 
    
}
?>
