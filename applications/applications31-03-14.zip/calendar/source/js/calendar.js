$(document).ready(function() {
    $('#loginBtn').click(loginBtnHandler);
    $('.reservationBtn').click(reserveDay);
    $('.cancelRepBtn').click(cancelDay);
});

function cancelDay(){
    $.ajax({
        url: $(this).attr('href')
    }).done(function(data){
        if (data != "1"){
            $('body').append('<p>При отмене репетиции произошла ошибка: ' + data + '</p>');
        }
        else{
            location.reload();
        }
    });
    return false;
}

function reserveDay(){
    var day = $(this).attr('id').split('_')[1];
    $.ajax({
        url: $(this).attr('href')
    }).done(function(data){
        if (data != "1"){
            $('body').append('<p>При бронировании репетиции произошла ошибка: ' + data + '</p>');
        }
        else{
            location.reload();
        }
    });
    return false;
}

function loginBtnHandler(){
    $('#loginForm').slideToggle();
    return false;
}

function pr(txt){
    console.log(txt);
}