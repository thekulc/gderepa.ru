<?
namespace admin\users;

class login extends \Admin {

    function default_method($new)
    {
        
    }
    
    function login($login, $password){
        $errors = null;
        if ($login == "") $errors['login'] = "Логин не может быть пустым";
        if ($password == "") $errors['password'] = "Пароль не может быть пустым";
        
        if (!$errors){
            $login = mysql_real_escape_string($login);
            $user = $this->get_controller("users","users", true)->getUserByLogin($login);
            if($user){
                $password = mysql_real_escape_string($password);
                $password = $this->get_controller("users","users", true)->getUserPassword($password, $user['solt']);
                if($password == $user['pass_cashe'])
                    $_SESSION['user'] = $user;
                else
                    $errors['noauth'] = "Логин или пароль некорректен";
            }
            else $errors['no_found'] = 'Пользователь с таким логином не зарегистрирован';
        }
        return $errors;
    }

}
?>
