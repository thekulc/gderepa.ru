<?
namespace users;

class logout extends \Controller {  
    
    function default_method()
    {
        //$this->set_global("user", "");
        unset ($_SESSION['user']);
        $this->redirect("/");
    }
    
}
?>
