<?
namespace users;

class registration extends \Controller {  
    
    function default_method()
    {
        $this->layout_show('newUser.html');
    }
    

}
?>
