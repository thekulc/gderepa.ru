<?
namespace users;

class users extends \Controller {  
    
    function default_method()
    {
        if (isset($this->id))
        {
            $idU = (int)$this->id;
            $user = $this->get_controller("users", "users", TRUE)->getUserById($idU);
            $this->layout_show("user.html",array('user'=>$user,'catTitle'=>$user['login']." (".$user['FIO'].")"));
        }
        
        else $this->redirect("/");
    }
    
}
?>
