<?
namespace attachment;

class attachment extends \Controller {  
    
    function default_method()
    {
        return $this->layout_show('index.html');
    }
}
?>
