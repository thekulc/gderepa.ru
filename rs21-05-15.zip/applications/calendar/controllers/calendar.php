<?
namespace calendar;

class calendar extends \Controller {  
    
    var $_date;
    const separator = '-';
	var $_rus;
    
    function default_method()
    {

        //$this->model()->getData('users');


		setlocale(LC_ALL, 'ru_RU.utf-8', 'rus_RUS.utf-8', 'ru_RU.utf8');
		$this->_rus = $this->model()->getRusMonthName();

        if (!isset($_SESSION['user']))
            $errs = $this->checkAuth();
        
        if (!is_string(filter_input(INPUT_GET, "date")) || filter_input(INPUT_GET, "date") == "")
            $date = date('Y-m-d');
        else{
			$date = date('Y-m-d', strtotime(filter_input(INPUT_GET, "date")));
		}
        $data = array();
        $data = $this->chooseAction($date);
		//pr($data);
        $data['user'] = $_SESSION['user'];
		$data['arendators'] = $this->model()->getArendators();
		//pr($data['arendators']);
        $data['errs'] = $errs;
        $data['page']['title'] = 'Расписание репетиционной студии на <u>' . date('F Y', strtotime($data['localdate']['choosed'])) . '</u>';
        //$a = $this->layout_get('calendar_main.html', $data);
        
        return $this->layout_show('calendar_main.html', $data);
    }
    
	
	
    function checkAuth(){
        $auto_auth = filter_input(INPUT_POST, 'auto_auth') === 'on' ? true : false;
        if (is_string(filter_input(INPUT_POST, 'login'))){
            $login = filter_input(INPUT_POST, 'login');
            $pass = filter_input(INPUT_POST, 'password');
            
//            $auto_auth = false;
            $errs = $this->get_controller("users", "login", true)->login($login, $pass, $auto_auth);
        }
        elseif (filter_input(INPUT_COOKIE, 'usr') && filter_input(INPUT_COOKIE, 'key')){
            $login = filter_input(INPUT_COOKIE, 'usr');
            $pass = filter_input(INPUT_COOKIE, 'key');
            
            $errs = $this->get_controller("users", "login", true)->login($login, $pass, $auto_auth, true);
        }
        
        return $errs;
    }
    
    function chooseAction($aDate) {
        $res = array();
        
        $lDate = $this->getDateObjByStr($aDate);
        if (isset($lDate['date']['year']) AND isset($lDate['date']['month'])){
            $res['calendar'] = $this->getMonth($aDate);
			$res['localdate']['today'] = $this->getDateObjByStr(date('Y-m-d'));
            $res['localdate']['choosed'] = $this->getDateObjByStr($aDate);
			
			$prevMonth = new \DateTime($aDate);
			$prevMonth = $prevMonth->sub(\DateInterval::createFromDateString('1 month'));
            $res['localdate']['prevDate'] = $this->getDateObjByStr($prevMonth->format('Y-m-d'));
			
			$nextMonth = new \DateTime($aDate);
			$nextMonth = $prevMonth->sub(\DateInterval::createFromDateString('-2 month'));
			$res['localdate']['nextDate'] = $this->getDateObjByStr($nextMonth->format('Y-m-d'));
        }
        return $res;
    }
    
    function getMonth($date, $events = true) {
        $resArr = array();
        
        $day = new \DateTime($date);
        $i = 0;
        $week = 0;
        $weekDay = 0;
        $format = "d-m-Y";
        $days = array();
        $interval = \DateInterval::createFromDateString('1 day');
        if (($weekDay = $day->format('N')) > 1) {
            $day = $day->sub(\DateInterval::createFromDateString($weekDay - 1 . ' days'));
            for ($i = 0; $i < $weekDay; $i++) {
                $days[$week][$i] = $day->format($format);
                $day->add($interval);
            }
        }
        do {
            if ($i++ > 0 && ($weekDay = $day->format('N')) == 1) {
                $week++;
            }
            $days[$week][$weekDay - 1] = $day->format($format);
            $day = $day->add($interval);
        } while ($week < 4);

        if (($lastWeek = count($days) - 1) > 1 && ($lastWeekDaysCount = count($days[$lastWeek])) < 7) {
            
            for ($i = $lastWeekDaysCount; $i < 7; $i++) {
                $days[$lastWeek][$i] = $day->format($format);
                $day->add($interval);
            }
        }
        
        if ($events)
            $events = $this->model()->getMonthEvents($date);
        else
            $events = null;
        
        for ($i = 0; $i < count($days); $i++) {
            foreach ($days[$i] as $day) {
                $resArr[$i][$day]['date'] = $day;
                if ($events)
                    $resArr[$i][$day]['events'] = $this->getEventByDate($events, $day);
            }
        }
        
        return $resArr;
    }
    
    function getEventByDate($events, $day) {
        $res = array();
        $format = 'd-m-Y';
        
        foreach ($events as $event) {
            if (date($format, strtotime($event->date)) === date($format, strtotime($day))){
                $res[] = $event;
            }
        }
        return $res;
    }
    
    function getDateObjByStr($dateStr) {
        $lDate = explode(self::separator, $dateStr);
        $temp = $this->validYear($lDate[0]);
		$result = null;
        if ($temp){
            $res['year'] = $temp;
            $temp = $this->validMonth($lDate[1]);
            if ($temp){
                $res['month'] = str_pad($temp, 2, "0", STR_PAD_LEFT);
				$monthName = $this->_rus[intval($temp)];
				$link = $res['year'].self::separator.$res['month'];
                $temp = isset($lDate[2]) ? $this->validDay($lDate[2]) : null;
                if ($temp){
                    $res['day'] = $temp;
					$link .= self::separator.str_pad($res['day'], 2, "0", STR_PAD_LEFT);
                }
                
            }
        }
        $result['date'] = $res;
		$result['monthName'] = $monthName;
		$result['link'] = $link;
        return $result;
    }
    
    private function validDay($day) {
        $res = null;
        if (strlen($day) > 0){
            $day = intval($day);
            if ($day > 0 && $day < 32){
                $res = $day;
            }
        }
        return $res;
    }
    
    private function validMonth($month) {
        $res = null;
        if (strlen($month) > 0){
            $month = intval($month);
            if ($month > 0 && $month < 13){
                $res = $month;
            }
        }
        return $res;
    }
    
    private function validYear($year) {
        $res = null;
        if (strlen($year) > 0){
            $year = intval($year);
            if ($year > 2000 && $year < 3000){
                $res = $year;
            }
        }
        return $res;
    }
    
    function getFormattedDate(){
        $year = $this->_date['year'];
        $month = $this->_date['month'];
        $day = $this->_date['day'];
        if (isset ($year) && isset($month) && isset($day) && $year != "" && $month != "" && $day != "")
            return str_pad($day, 2, "0", STR_PAD_LEFT) . self::separator . str_pad($month, 2, "0", STR_PAD_LEFT) . self::separator . $year;
    }
}
?>
