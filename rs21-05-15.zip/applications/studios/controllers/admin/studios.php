<?
namespace admin\studios;

class studios extends \Admin {

    function default_method()
    {
        return $this->layout_show('admin/studios/studios.html');
    }
}
?>
