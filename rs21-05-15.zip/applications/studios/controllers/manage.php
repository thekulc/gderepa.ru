<?php
namespace studios;

class manage extends \Controller{
	function default_method(){
		$data['page']['title'] = "Управление студиями";
		$data['studios'] = $this->model()->getStudiosByUserId($_SESSION['user']['id'], array(4,6), $err);
		$this->layout_show('studios/manage.html', $data);
	}
}
?>