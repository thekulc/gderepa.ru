<?
namespace studios;

class studios extends \Controller {  
    
    function default_method()
    {
    	$data['page']['title'] = "Список студий";

        return $this->layout_show('studios/studios.html', $data);
    }
}
?>
