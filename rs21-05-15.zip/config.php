<?php
$config = array();

//engine
$config['caching']			= 0;
$config['dev_mode']			= 0;
$config['alias']			= 1;
$config['admin_mail']		= 'thekulc@gmail.com';
$config['excluded_folders']	= 'source,uploads,templates';
$config['layout']			= 'Default';

$config['socialAuth']['client_id']		= "4901558";
$config['socialAuth']['client_secret']	= "oSuJ5AOUeUriNdDeRIUK";
$config['socialAuth']['redirect_uri']	= "http://rs/users/auth";

//database
$config['host']				= 'localhost';
$config['database']			= 'agregatordb';
$config['user']				= 'root';
$config['password']			= '';

//kulc
$config['FROM_NAME']		= 'Little Byte';
$config['FROM_MAIL']		= 'contact@littlebyte.co';
$config['SEND_MAIL_ADDRESS']= 'contact@littlebyte.co';
$config['TOKEN']			= 'token';