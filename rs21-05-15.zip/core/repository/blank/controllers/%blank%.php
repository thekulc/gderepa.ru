<?
namespace %blank%;

class %blank% extends \Controller {  
    
    function default_method()
    {
        return $this->layout_show('%blank%/%blank%.html');
    }
}
?>
