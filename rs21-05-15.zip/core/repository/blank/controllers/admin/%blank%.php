<?
namespace admin\%blank%;

class %blank% extends \Admin {

    function default_method()
    {
        return $this->layout_show('admin/%blank%/%blank%.html');
    }
}
?>
