<?php
namespace %blank%;

class mdl_%blank% extends \Model{

}