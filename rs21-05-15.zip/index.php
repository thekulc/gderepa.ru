<?php
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
if(!session_id()) session_start();

$zone = @$_SESSION['user']['timezone'] ? $_SESSION['user']['timezone'] : "Europe/Moscow";
date_default_timezone_set($zone);

if((defined('DEV_MODE') && DEV_MODE==1) OR isset($_GET['debug'])) {
    error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
    $memstart = memory_get_usage();
    $start = microtime(1);
}
else error_reporting(0);

require_once('core/config.php');
require_once('core/database.php');
require_once('core/functions.php');
require_once('core/router.php');

if((defined('DEV_MODE') && DEV_MODE==1) OR isset($_GET['debug'])) {
    
    $memend = memory_get_usage();
    $end = microtime(1);
    echo "<div id='dev_info' style='font-size: 12px; z-index:90; position:fixed; bottom:20px; left:30px; background-color:white; padding: 10px 10px 10px 20px; border: 1px solid gray; border-radius: 10px; box-shadow: 0 0 10px gray; min-width: 200px;'><a style='float:right;' href='#' onclick=getElementById('dev_info').parentNode.removeChild(getElementById('dev_info')); return false;>Закрыть</a>";
    echo "<pre style='font-family: Arial;'><b style='font-family: Arial;'>Ресурсы:</b>\n"
    .substr(($end-$start)*1000,0,6)." мсек\n"
    .substr(($memend-$memstart)/1024/1024,0,6)." МБ ОЗУ\n";    
    echo "</div>";
}

?>
