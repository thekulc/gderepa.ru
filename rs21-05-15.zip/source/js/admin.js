function valid(elem,min,max)
{
    var msg='';
    var txt=$(elem).val();
    
    var res = false;
    var out=$(elem).next('span');
    if(txt.length<min || txt.length>max)
        {
            msg=' в пределах '+min+' и '+max;
            out.css('color','red');
            out.html("(!) "+msg);
            $(elem).css('background-color','rgba(255, 0, 0, .2)');
            res = false;
        }
    else 
        {
            out.html("Ok");
            out.css('color', 'green');
            $(elem).css('background-color','rgba(0, 255, 0, .2)');
            res = true;
        }
    $('#statusAuth').append(msg+' ');
    return res;
}

function mailValid(elem){
    var msg;
    var res = false;
    var out = $(elem).next('span');
    if(!validateEmail($(elem).val()))
        {
            msg='Почта введена неверно';
            out.css('color','red');
            out.html("(!) "+msg);
            
            res = false;
        }
    else 
        {
            out.html("Ok");
            out.css('color', 'green');
            $(elem).css('background-color','rgba(0, 255, 0, .2)');
            res = true;
        }
    return res;
    
}

function validForm(){
    var res = false;
        
        res = mailValid($('input[name=email]'));
        //var els = $('input[type=text]');
        
        $('input[type=text]').each(function(idx, els){
            res *= valid($(els));
        });
        
        return res === 0 ? false : true;
}



function validateEmail(email){
    
    var splitted = email.match("^(.+)@(.+)$");
    if (splitted == null) return false;
    if (splitted[1] != null)
    {
        var regexp_user = /^\"?[\w-_\.]*\"?$/;
        if (splitted[1].match(regexp_user) == null) return false;
    }
    if (splitted[2] != null)
    {
        var regexp_domain = /^[\w-\.]*\.[A-Za-z]{2,4}$/;
        if (splitted[2].match(regexp_domain) == null)
        {
            var regexp_ip = /^\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\]$/;
            if (splitted[2].match(regexp_ip) == null) return false;
        } // if
        return true;
    }
    return false;
}

var Old = "";

function checkLogin(elem,old){
    var res = false;
    var login = $(elem).val();
    var min = 3;
    var max = 255;
    if (old) Old=old;
    var txt = $(elem).next('span');
    if (old != login)
    {
        if (valid(elem,min,max))
        {
            
            $.ajax({
               type:"POST" ,
               data:'checkLogin='+login,
               async:false,
               url: '/admin/users/',
               success: function(status){
                    if(status!='true') 
                        {
                            txt.html('(!) Этот логин занят');
                            txt.css('color', 'red');
                            res = false;
                        }
                    else {
                        txt.html('Ok');
                        txt.css('color', 'green');
                        res = true;
                    }}
            });
        }
        else {
                $(elem).next('span').html("(!) В пределах "+min+" и "+max);
                $(elem).next('span').css('color','red');
                res = false;
        }
    }
    else {
        txt.html('Ok');
        txt.css('color', 'green');
        res=true;
    }
    return res;
}

function onPassWright(pwd2){
    var res = false;
    var pwd1 = $('[name="password"]');
    var msgOut = $(pwd2).next('span');
    var prnt = pwd2;
    pwd2 = $(pwd2).val();
    if (pwd2!='')
        if ($(pwd1).val() == pwd2)
            {
                res=true;
                msgOut.html('Ok');
                msgOut.css('color', 'green');
                $(elem).css('background-color','rgba(0, 255, 0, .2)');
            }
        else{
                msgOut.html('(!) Пароли не совпадают');
                msgOut.css('color', 'red');
                $(elem).css('background-color','rgba(255, 0, 0, .2)');
                res=false;
            }
    return res;
}

var htmleditor;
function toggleeditor($obj){
    var lId = 'htmleditor';
    if ($($obj).attr('id')){
        htmleditor.destroy();
        $($obj).removeAttr('id');
    }
    else {
        $($obj).attr('id', lId);
        htmleditor = CKEDITOR.replace( lId );
    }
    
}

function showFullImage(){
    if($.lightbox){
        $("a.showFullImage").lightBox({
            imageLoading: '/source/images/lightbox/lightbox-ico-loading.gif',
            imageBtnClose: '/source/images/lightbox/lightbox-btn-close.gif',
            imageBlank: '/source/images/lightbox/lightbox-blank.gif',
            containerResizeSpeed: 0
        });
    }
    
}

function showEvents(){
    $('.showEvents').click(function(){
        $('.galeryEvents').toggle('fast');
        return false;
    });
    
}

$(document).ready(function(){
    
    showEvents();

    showFullImage();
    
    $('.back_form').submit(validForm);
    
    $('#toggleeditor').click(function(){
        toggleeditor($(this).parent().children('textarea'));
        return false;
    });
    
});

function pr(txt){
    console.log(txt);
}